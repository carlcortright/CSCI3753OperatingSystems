# Operating Systems: Project 3 Multithreading
##### Author: Carl Cortright
##### Date: 10/15/2016

## Building

Use the make utility to build the file.

## Running

To run the test code run:

~~~~./multi-lookup in.txt in2.txt out.txt ~~~~
